//
//  CustomCellView.h
//  tabletest
//
//  Created by Craig Booker on 5/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableCell : UITableViewCell
{
    IBOutlet UILabel *sensorLabel;
    IBOutlet UILabel *pidLabel;
    
}
//@property (nonatomic) *textLabel;
@end
