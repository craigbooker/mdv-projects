//
//  CarDetailViewController.m
//  TableViewStory
//
//  Created by Craig Booker on 5/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CarDetailViewController.h"

@implementation CarDetailViewController
@synthesize sensorLabel = _sensorLabel;
@synthesize pidLabel = _pidLabel;
@synthesize imageView = _imageView;
@synthesize sensorDetailName = _sensorDetailName;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.sensorLabel.text = [self.sensorDetailName objectAtIndex:0];
    self.pidLabel.text = [self.sensorDetailName objectAtIndex:1];
    self.imageView.image = [UIImage imageNamed:[self.sensorDetailName objectAtIndex:2]];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
