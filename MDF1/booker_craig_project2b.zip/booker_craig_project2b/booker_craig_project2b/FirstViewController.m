//
//  FirstViewController.m
//  booker_craig_project2b
//
//  Created by Craig Booker on 5/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FirstViewController.h"
#import "CustomTableCell.h"

@implementation FirstViewController



							
- (void)viewDidLoad
{
    
    sensorNameList = [[NSMutableArray alloc] initWithObjects:@"Absolute Throttle Position",
                      @"Engine RPM", @"Vehicle Speed",
                      @"Calculated Load Value",
                      @"Timing Advance (Cyl#1)",
                      @"Intake Manifold Pressure",
                      @"Air Flow Rate (MAF Sensor)", 
                      @"Fuel System Status", 
                      @"Short Term Fuel Trim (Bank 1)", 
                      @"Long Term Fuel Trim (Bank 1)", 
                      @"Short Term Fuel Trim (Bank 2)", 
                      @"Long Term Fuel Trim (Bank 2)", 
                      @"Intake Air Temperature", 
                      @"Coolant Temperature", 
                      @"Fuel Pressure (guage)", 
                      @"O2 Sensor 1, Bank 1", 
                      @"O2 Sensor 2, Bank 1", 
                      @"O2 Sensor 3, Bank 1", 
                      @"O2 Sensor 4, Bank 1", 
                      @"O2 Sensor 1, Bank 2", 
                      @"O2 Sensor 2, Bank 2", 
                      @"O2 Sensor 3, Bank 2", 
                      @"O2 Sensor 4, Bank 2", 
                      @"Time Since Engine Start", 
                      @"Fuel Level Input", 
                      @"Barometric Pressure (Absolute)", 
                      @"Catalytic Converter Temp B1S1", 
                      @"Catalytic Converter Temp B2S1", 
                      @"Catalytic Converter Temp B1S2", 
                      @"Catalytic Converter Temp B2S2", 
                      @"ECU Voltage", 
                      @"Absolute Engine Load", 
                      @"Ambient Air Temperature"
                      ,nil];
    

    
    [super viewDidLoad];
 	
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [sensorNameList count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	static NSString *CellIdentifier = @"Cell";
    CustomTableCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];

	if (cell == nil) { 
        //cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        NSArray* views = [[NSBundle mainBundle] loadNibNamed:@"CustomCellView" owner:nil options:nil];
        for (UIView *view in views)
        {
            
            if([view isKindOfClass:[CustomTableCell class]])
            {
                cell = (CustomTableCell*)view;
            }
            
        }    
    }
    //cell.textLabel.text = (NSString*)[sensorNameList objectAtIndex:indexPath.row];
    return cell;
}

@end
