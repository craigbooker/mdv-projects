//
//  AppDelegate.h
//  booker_craig_project1
//
//  Created by Craig Booker on 5/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "FirstViewController.h"
//#import "SecondViewController.h"
#import "ThirdViewController.h"

@class RootViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate, UITabBarDelegate>
{
   // FirstViewController *tableView;
    ThirdViewController *mainMapView;
    
    NSMutableArray *locArray;

    UITabBarController *tabController;
}
@property (strong, nonatomic) NSMutableArray *locArray;
@property (strong, nonatomic) UITabBarController *tabController;
@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ThirdViewController *mainMapView;

@end
