//
//  SensorTableViewCell.m
//  WindowTabBar
//
//  Created by Craig Booker on 5/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SensorTableViewCell.h"

@implementation SensorTableViewCell
@synthesize sensorLabel = _sensorLabel;
@synthesize pidLabel = _pidLabel;
@synthesize sensorImage = _sensorImage;


@end
