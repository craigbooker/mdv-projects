//
//  Tweet.h
//  ParsingXMLTutorial
//
//  Created by Craig Booker on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Tweet : NSObject

@property (strong, nonatomic)NSString *content;
@property (strong, nonatomic)NSString *dateCreated;


@end
