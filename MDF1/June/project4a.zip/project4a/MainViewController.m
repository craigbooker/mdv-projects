//
//  ThirdViewController.m
//  booker_craig_project2b
//
//  Created by Craig Booker on 5/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MainViewController.h"
#import "WebViewController.h"
#import "DetailViewController.h"

#import "MyTweet.h"
#import "AppDelegate.h"

@implementation MainViewController
@synthesize mainViewArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Tweets", @"Tweets");
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
   // UIBarButtonItem *topRightButton = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(toggleEditState)];
    self.navigationController.navigationBar.tintColor=[UIColor blackColor];
    
    //self.navigationItem.rightBarButtonItem = topRightButton;

    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate dispLocArray];
    mainViewArray = appDelegate.mainArray;
    
    NSLog(@"from appDelegate : %i",appDelegate.mainArray.count);
    NSLog(@"copied array from appDelegate : %i",mainViewArray.count);
    
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}    
    
-(void)toggleEditState
{
    [myMapTableView setEditing:!myMapTableView.editing animated:YES];
    if (myMapTableView.editing)
    {
        [self.navigationItem.rightBarButtonItem setTitle:@"Done"];
    }
    else {
        [self.navigationItem.rightBarButtonItem setTitle:@"Edit"];
    }


}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return mainViewArray.count;  
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) 
    {
        [mainViewArray removeObjectAtIndex:indexPath.row];
        NSLog(@"I would like to delete row %d", mainViewArray.count);
        [myMapTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:true];
    } 
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // This is where I would add something...
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
	if (cell == nil) { 
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    MyTweet *myLocation = [mainViewArray objectAtIndex:indexPath.row];
    cell.textLabel.text = myLocation.title;
    return cell;
}    
/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
	if (cell == nil) { 
        cell = [[CustomTableViewCell alloc] initWithStyle:[UITableViewCellStyleDefault reuseIdentifier:CellIdentifier]];
                NSArray* views = [[NSBundle mainBundle] loadNibNamed:@"CustomTableViewCell" owner:nil options:nil];
                for (UIView *view in views)
                {
                    
                    if([view isKindOfClass:[CustomTableViewCell class]])
                    {
                        cell = (CustomTableViewCell*)view;
                    }
                }    
    }
    MyTweet *myLocation = [self.xArray objectAtIndex:indexPath.row];
    cell.locationNameLabel.text = myLocation.title;
    cell.bizLocationLabel.text = myLocation.location;
    return cell;
}  
*/

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DetailViewController *myDetailMap = [[DetailViewController alloc] initWithNibName:@"DetailView" bundle:nil];
    if(myDetailMap != nil)
    {
        [self.navigationController pushViewController:myDetailMap animated:YES];
        MyTweet *showCoordDetails = [mainViewArray objectAtIndex:indexPath.row];
        //[myDetailMap showMyMap:showCoordDetails.coordinate title:showCoordDetails.title];
    }

}


@end
