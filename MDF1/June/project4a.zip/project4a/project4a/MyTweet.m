//
//  MyTweet.m
//  project4a
//
//  Created by Craig Booker on 6/21/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MyTweet.h"

@implementation MyTweet
@synthesize content;
@synthesize dateCreated;
@synthesize title;
@synthesize location;
@synthesize coordinate;


@end