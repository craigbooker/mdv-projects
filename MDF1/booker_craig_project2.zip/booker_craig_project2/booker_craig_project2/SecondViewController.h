//
//  SecondViewController.h
//  booker_craig_project2
//
//  Created by Craig Booker on 5/12/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@end
