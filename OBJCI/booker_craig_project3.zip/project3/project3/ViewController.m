//
//  ViewController.m
//  project3
//
//  Created by Craig Booker on 2/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

NSString *appendStrgOne = @"First append string";
NSString *appendStrgTwo = @"Second append string";

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
/*- (void)viewDidAppear
{ */
/* ::::::::: Add Function  :::::::::  
 This function will take two NSInteger or int types and return the result of an addition between these two.
 
 
 
 
 */

- (int)addNumber:(int)theFirstInteger secondInteger:(int)theSecondInteger
{
    int temp = theFirstInteger;
    temp += theSecondInteger;
    NSLog(@"Sum of two args = %d", temp);
    return temp;
}

/* ::::::::: Compare Function  :::::::::  
 Create a function called Compare that takes two NSInteger values. Return true or false based on whether the values are equal.
 Whatever calls this function needs to capture the return value.
 */
-(bool)compareNumber:(NSInteger)theCompIntOne compIntTwo:(NSInteger)theCompIntTwo
{
    bool isCompTrue;
if (compIntOne == compIntTwo) 
{
    isCompTrue = true;
} 
else
isCompTrue = false;

    return isCompTrue;
}



/* ::::::::: Append Function  :::::::::  
 This function will take two NSStrings and return a new NSString containing the appended strings.
*/
- (NSString*)appendString:(NSString*)theAppendStrgOne appendStrgTwo:(NSString*)theAppendStrgTwo
{
//int strgLength = [appendStrgOne length];
NSString *result = [NSString alloc];
result = [result stringByAppendingString:theAppendStrgOne];
result = [result stringByAppendingString:theAppendStrgTwo];
return result;
}

/*
    [super viewDidAppear];
} */
@end
