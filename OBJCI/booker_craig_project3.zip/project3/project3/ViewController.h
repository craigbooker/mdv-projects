//
//  ViewController.h
//  project3
//
//  Created by Craig Booker on 2/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    int firstInteger, secondInteger; 
    NSString *appendStrgOne;
    NSString *appendStrgTwo;
    NSInteger *compIntOne;
    NSInteger *compIntTwo;
}

-(int)addNumber: (int)firstInteger secondInteger:(int)theSecondInteger;
-(bool)compareNumber:(NSInteger)theCompIntOne compIntTwo:(NSInteger)theCompIntTwo;

-(NSString *) appendString: (NSString*)appendStrgOne appendStrgTwo:(NSString*) appendStrgTwo;

-(void)printResults:(int)resultSum;

@end
