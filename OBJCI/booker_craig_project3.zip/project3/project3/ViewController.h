//
//  ViewController.h
//  project3
//
//  Created by Craig Booker on 2/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
  //  int addReturnVal;
    NSInteger *firstInteger;
    NSInteger *secondInteger;
}


-(NSInteger)addFunction;


-(void)printResults:(int)resultSum;

@end
