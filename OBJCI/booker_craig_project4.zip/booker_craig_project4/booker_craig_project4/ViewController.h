//
//  ViewController.h
//  booker_craig_project4
//
//  Created by Craig Booker on 2/19/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UITextField *textField;
    UILabel *infoLabel;
    UILabel *textStatusLabel;
}
@end
