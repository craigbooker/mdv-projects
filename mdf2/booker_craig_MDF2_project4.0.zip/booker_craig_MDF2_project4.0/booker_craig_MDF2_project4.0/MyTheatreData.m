//
//  MyTheatreData.m
//  booker_craig_MDF2_project4.0
//
//  Created by Craig Booker on 8/18/12.
//  Copyright (c) 2012 Craig Booker. All rights reserved.
//

#import "MyTheatreData.h"

@implementation MyTheatreData
@synthesize xTheatreName;
@synthesize xTheatreLocation;
@synthesize xTheatrePhoto;
@synthesize xTheatreMovies;
@synthesize xMovieTimes;
@synthesize xMovieImages;
@synthesize xMovieTrailer;
@end
