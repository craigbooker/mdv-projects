//
//  CustomTableViewCellCell.m
//  Interface Export
//
//  Created by Craig Booker on 7/31/12.
//  Copyright (c) 2012 Less Code Limited. All rights reserved.
//

#import "CustomTableCell.h"

@implementation CustomTableCell
@synthesize movieNameLabel = _movieNameLabel;
@synthesize movieTimesLabel = _movieTimesLabel;
@synthesize thumbnailImageView = _thumbnailImageView;




@end
