//
//  MyEventData.m
//  booker_craig_project1
//
//  Created by Craig Booker on 8/2/12.
//  Copyright (c) 2012 Semantik Media, LLC. All rights reserved.
//

#import "MyEventData.h"

@implementation MyEventData
@synthesize xEventTitle;
@synthesize xEventLocation;
@synthesize xEventDate;
@synthesize xEventTime;

@end
