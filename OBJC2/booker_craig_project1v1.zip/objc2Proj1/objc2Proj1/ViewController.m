//
//  ViewController.m
//  objc2Proj1
//
//  Created by Craig Booker on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "ShapeClass.h"
#import "SquareClass.h"
#import "TriangleClass.h"
#import "RectangleClass.h"
#import "ShapeFactory.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    ShapeFactory *shapeFactory = [[ShapeFactory alloc] init];
    if (shapeFactory != nil)
    {
        ShapeClass *square = [shapeFactory CreateShape:0];
        [square GetArea];
        [square printInfo];
        ShapeClass *triangle = [shapeFactory CreateShape:1];
        [triangle GetArea];
        [square printInfo];        
        ShapeClass *rectangle = [shapeFactory CreateShape:2];
        [rectangle GetArea];
        [rectangle printInfo];
    }
    /*
    TriangleClass *triangleClass = [[TriangleClass alloc] init];
    if (triangleClass != nil)
    {
        [triangleClass printInfo];
    }    
    SquareClass *squareClass = [[SquareClass alloc] init];
    if (squareClass != nil)
    {
        [squareClass printInfo];
    } 
    RectangleClass *rectangleClass = [[RectangleClass alloc] init];
    if (rectangleClass != nil)
    {
        [rectangleClass printInfo];
    } 
    */
    
    UILabel *textLabel = [[UILabel alloc] initWithFrame:CGRectMake(10.0f, 10.0f, 100.0f, 30.0f)];
    if (textLabel != nil)
    {
        textLabel.text = @"Username: ";
        [self.view addSubview:textLabel];
    }
    textField = [[UITextField alloc] initWithFrame:CGRectMake(100.0f, 10.0f, 200.0f, 30.0f)];
    if (textField != nil)
    {
        textField.borderStyle = UITextBorderStyleRoundedRect;
        [self.view addSubview:textField];
    }
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    if (button != nil)
    {
        button.frame = CGRectMake(225.0f, 50.0f, 75.0f, 30.0f);
        [button setTitle:@"Login" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(onClick) forControlEvents: UIControlEventTouchUpInside];
        [self.view addSubview:button];
    }
    textStatusLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 100.0f, 320.0f, 80.0f)];
    if (textStatusLabel != nil)
    {
        textStatusLabel.text = @"Please Enter Username ";
        textStatusLabel.backgroundColor = [UIColor lightGrayColor];
        textStatusLabel.textColor = [UIColor blueColor];
        textStatusLabel.textAlignment = UITextAlignmentCenter;        
        [self.view addSubview:textStatusLabel];
    }
    UIButton *showDateButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    if (showDateButton != nil)
    {
        showDateButton.frame = CGRectMake(10.0f, 250.0f, 125.0f, 50.0f);
        [showDateButton setTitle:@"Show Date" forState:UIControlStateNormal];
        [showDateButton addTarget:self action:@selector(showDate) forControlEvents: UIControlEventTouchUpInside];
        [self.view addSubview:showDateButton];
    }
    
    //[dateLabel setText:str];
    // }
    UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeInfoDark];
    if (infoButton != nil)
    {
        infoButton.frame = CGRectMake(10.0f, 315.0f, 25.0f, 25.0f);
        [infoButton addTarget:self action:@selector(showInfo) forControlEvents: UIControlEventTouchUpInside];
        [self.view addSubview:infoButton];
    }
    infoLabel = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 340.0f, 320.0f, 100.0f)];
    if (infoLabel != nil)
    {
        
        infoLabel.backgroundColor = [UIColor whiteColor];
        infoLabel.textColor = [UIColor greenColor];
        infoLabel.textAlignment = UITextAlignmentCenter;
        infoLabel.numberOfLines = 7;
        infoLabel.lineBreakMode = UILineBreakModeWordWrap;
        [self.view addSubview:infoLabel];
    }
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
