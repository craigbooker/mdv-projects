//
//  ShapeClass.m
//  objc2Proj1
//
//  Created by Craig Booker on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ShapeClass.h"

@implementation ShapeClass

-(id)initWithDetails: (int)numSides name:(NSString*)name
{

    if (self = [super init])
    {
       // shapeType = type;
        _numSides = numSides;
        _name = name;
    }
    return self;
}
-(int)GetArea
{
    areaVal = 0.5f * (shapeBase * shapeHeight);
    return areaVal;
}

-(int)GetNumSides
{
    return _numSides;    
}

-(NSString*)GetName
{
    return _name; 
}

-(void)printInfo
{
    NSLog(@"Shape %@ Area:%f", _name, areaVal);
}

@end