//
//  ViewController.h
//  objc2Proj1
//
//  Created by Craig Booker on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShapeClass.h"
#import "SquareClass.h"
#import "TriangleClass.h"
#import "RectangleClass.h"

@interface ViewController : UIViewController
{
    UITextField *textField;
    UILabel *infoLabel;
    UILabel *textStatusLabel;
}
@end
