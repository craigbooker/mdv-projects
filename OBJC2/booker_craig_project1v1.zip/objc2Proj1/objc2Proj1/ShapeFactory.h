//
//  ShapeFactory.h
//  objc2Proj1
//
//  Created by Craig Booker on 3/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ShapeClass.h"

@interface ShapeFactory : NSObject

-(ShapeClass*)CreateShape:(NSInteger)shapeType;

@end
