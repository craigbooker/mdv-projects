//
//  ShapeClass.h
//  objc2Proj1
//
//  Created by Craig Booker on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShapeClass : NSObject
{
    float areaVal;
    float shapeHeight;
    float shapeBase;
    
@protected 
    //EShapeType shapeType;
    int _numSides;
    NSString* _name;

}

-(int)GetArea;
-(int)GetNumSides;
-(NSString*)GetName;
-(void)printInfo;


@end
