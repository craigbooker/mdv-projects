//
//  ViewController.h
//  practice11
//
//  Created by Craig Booker on 4/24/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UITextField *dataField;
}
- (IBAction)onClick:(id)sender;
@end
