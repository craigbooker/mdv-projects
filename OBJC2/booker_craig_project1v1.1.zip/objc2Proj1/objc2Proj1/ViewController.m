//
//  ViewController.m
//  objc2Proj1
//
//  Created by Craig Booker on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "ShapeClass.h"
#import "SquareClass.h"
#import "TriangleClass.h"
#import "RectangleClass.h"
#import "ShapeFactory.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{

    ShapeFactory *shapeFactory = [[ShapeFactory alloc] init];
    if (shapeFactory != nil)
    {
        ShapeClass *square = [shapeFactory CreateShape:0];
        [square GetArea];
        [square savePrintInfo];
        
        ShapeClass *triangle = [shapeFactory CreateShape:1];
        [triangle GetArea];
        [triangle savePrintInfo];
        
        ShapeClass *rectangle = [shapeFactory CreateShape:2];
        [rectangle GetArea];
        [rectangle savePrintInfo];
       // [printResults setText:areaOutput];        
        

    }
        

 
    printResults = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 100.0f)];
    if (printResults != nil)
    {
        
        printResults.backgroundColor = [UIColor whiteColor];
        printResults.textColor = [UIColor blackColor];
        printResults.textAlignment = UITextAlignmentCenter;
        printResults.numberOfLines = 7;
        printResults.lineBreakMode = UILineBreakModeWordWrap;
        [self.view addSubview:printResults];
    }
    /*
    printResults1 = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 100.0f, 320.0f, 100.0f)];
    if (printResults2 != nil)
    {
        
        printResults2.backgroundColor = [UIColor whiteColor];
        printResults2.textColor = [UIColor blackColor];
        printResults2.textAlignment = UITextAlignmentCenter;
        printResults2.numberOfLines = 7;
        printResults2.lineBreakMode = UILineBreakModeWordWrap;
        [self.view addSubview:printResults2];
    }
    printResults2 = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 200.0f, 320.0f, 100.0f)];
    if (printResults3 != nil)
    {
        
        printResults3.backgroundColor = [UIColor whiteColor];
        printResults3.textColor = [UIColor blackColor];
        printResults3.textAlignment = UITextAlignmentCenter;
        printResults3.numberOfLines = 7;
        printResults3.lineBreakMode = UILineBreakModeWordWrap;
        [self.view addSubview:printResults3];
    }
*/
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
