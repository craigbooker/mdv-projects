//
//  ShapeFactory.m
//  objc2Proj1
//
//  Created by Craig Booker on 3/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ShapeFactory.h"
#import "ShapeClass.h"

@implementation ShapeFactory
 
-(ShapeClass*)CreateShape:(NSInteger)shapeType
{
    //int _shapeType = shapeType;
    if (shapeType == 0)
    {
        return [[ShapeClass alloc] initWithDetails:0 name:@"square"];
    }
    else if (shapeType == 1)
    {
        return [[ShapeClass alloc] initWithDetails:1 name:@"triangle"];
        
    }
    else if (shapeType == 2)
    {
        return [[ShapeClass alloc] initWithDetails:2 name:@"rectangle"];
    
    }
    return nil;
    
}
@end
