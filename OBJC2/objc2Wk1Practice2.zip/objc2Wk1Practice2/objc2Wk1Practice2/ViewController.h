//
//  ViewController.h
//  objc2Wk1Practice2
//
//  Created by Craig Booker on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseShape.h"
#import "SquareShape.h"
#import "TriangleShape.h"

@interface ViewController : UIViewController

@end
