//
//  TopViewController.h
//  project3
//
//  Created by Craig Booker on 4/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
/*
@protocol MyDelegate <NSObject>

-(void)PassInfo:(NSString*)info;

@end
*/

@interface TopViewController : UIViewController <UITextFieldDelegate>
 {
 
 }
/*
{
    id <MyDelegate> delegate;
    IBOutlet UITextInputMode *eventTextInput;
    
}
-(IBAction)onSave:(id)sender;
@property (nonatomic, assign) id<MyDelegate> delegate;
*/
@end
//-(IBAction)onCloseKeyboard:(id)sender;