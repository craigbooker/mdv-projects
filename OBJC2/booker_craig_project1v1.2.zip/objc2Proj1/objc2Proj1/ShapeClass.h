//
//  ShapeClass.h
//  objc2Proj1
//
//  Created by Craig Booker on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShapeClass : NSObject
{
@protected 
    int _numSides;
    int _areaVal;
    int _type;
    NSString* _name;
    NSString *textOutput;
}

-(id)initWithDetails:(int)numSides name:(NSString*)name areaVal:(int)areaVal;
-(int)GetArea;

-(NSString*)getTextOutput;

@end
