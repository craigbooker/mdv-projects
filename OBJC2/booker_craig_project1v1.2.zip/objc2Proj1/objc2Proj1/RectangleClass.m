//
//  RectangleClass.m
//  objc2Proj1
//
//  Created by Craig Booker on 3/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RectangleClass.h"
#import "ShapeClass.h"

@implementation RectangleClass
-(id)initWithDetails: (int)numSides name:(NSString*)name
{
    if (self = [super init])
    {
        //[self setAttributes:SHAPETYPE_RECTANGLE name:@"Rectangle" shapeNumSides:4];
        //shapeType = SHAPETYPE_RECTANGLE;
        _name = name;
        numSides = 4;
    }
    return self;
}

-(int)GetArea
{
    areaVal = (9 * 3);
    return areaVal;
}
@end
