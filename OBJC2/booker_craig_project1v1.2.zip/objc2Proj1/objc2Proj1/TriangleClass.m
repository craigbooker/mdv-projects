//
//  TriangleClass.m
//  objc2Proj1
//
//  Created by Craig Booker on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ShapeClass.h"
#import "TriangleClass.h"


@implementation TriangleClass
-(id)init
{
    if (self = [super init])
    {
        [self initWithDetails:1 GetNumSides:3 GetName:@"Traingle" areaVal:0]; 
        
    }
    return self;
}
-(int)GetArea
{
    areaVal = 0.5f * (4 * 5);
    //NSLog(@"Inside GetArea areaVal= %f", areaVal);
    return areaVal;
}
-(NSString*)getTextOutput
{
    textOutput = [NSString stringWithFormat:@"", GetName, areaVal ];
    return textOutput;

}
@end
