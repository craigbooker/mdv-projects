//
//  AddEventViewController.h
//  project3
//
//  Created by Craig Booker on 4/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddEventViewController : UIViewController
{
    IBOutlet UITextInputMode *eventTextInput;
    
}

//-(IBAction)onCloseKeyboard:(id)sender;
@end
