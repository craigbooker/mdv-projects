//
//  ViewController.h
//  project3
//
//  Created by Craig Booker on 4/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UITextView *textView;
     NSString *eventOutput;
}

-(IBAction)onAddEvent:(id)sender;
-(void) loadEvents:(NSString *)eventOutput;
@end
